CREATE DATABASE BIKESTORE

USE BIKESTORE
 
 
CREATE SCHEMA SALES

CREATE SCHEMA PRODUCTION
---drop table SALES.CUSTOMERS

CREATE Table SALES.CUSTOMERS( 
customer_id     INT PRIMARY KEY,   
 first_name      VARCHAR(20) NOT NULL,
 last_name       VARCHAR(10),
 email           VARCHAR(100) unique ,
 street          VARCHAR (100),
 city            VARCHAR (50),
 state           VARCHAR (50),
 zip_code        VARCHAR (5)          
 )

 ----Creating STORES table--------
 --drop table SALES.ORDERS
  CREATE TABLE SALES.STORES(
 store_id        INT PRIMARY KEY,   
 store_name      VARCHAR(20) NOT NULL,
 phone           VARCHAR(10)unique,
 email           VARCHAR(100) unique ,
 street          VARCHAR (100),
 city            VARCHAR (50),
 state           VARCHAR (50),
 zip_code        VARCHAR (5)          
 ) 

 -------creating STAFFS TABLE---------
 
 CREATE TABLE SALES.STAFFS(
 staff_id      INT PRIMARY KEY,   
 first_name     VARCHAR(20) NOT NULL,
 last_name      VARCHAR(10),
 email          VARCHAR(100) unique ,
 store_id       INT NOT NULL,
 active         VARCHAR(20),
 phone          VARCHAR(20) unique,
 manager_id      INT,
 CONSTRAINT fk_staff FOREIGN KEY(store_id)
 REFERENCES SALES.STORES (store_id)   
 )

 --------Creating Orders Table ---------
 -----drop table SALES.ORDERS
 CREATE TABLE SALES.ORDERS (
 order_id         INT PRIMARY KEY,
 customer_id      INT ,    
 order_status     VARCHAR(20) NOT NULL,
 order_date       DATE NOT NULL,
 Rquired_date     DATE NOT NULL,
 shiped_Date      DATE NOT NULL,
 store_id         INT,
 state            INT,
 zip_code         VARCHAR (5) 
 CONSTRAINT fk_customer_id  FOREIGN KEY( customer_id ) 
 REFERENCES SALES.CUSTOMERS(customer_id)

 )
 
 ------- creating ORDER_ITEM--------

---- drop table SALES.ORDER_ITEMS --------

 CREATE TABLE SALES.ORDER_ITEMS (
 order_id      INT ,
 item_id       INT PRIMARY KEY,
 product_id    INT ,   
quantity       INT CHECK(quantity> 0) not null,
 list_price    INT CHECK(list_price> 0) not null,
 discount      VARCHAR(50),
 CONSTRAINT fk_order1_id  FOREIGN KEY (order_id)
  REFERENCES SALES.ORDERS(order_id ),  
  CONSTRAINT FK_product_id foreign key (product_id ) REFERENCES PRODUCTION.PRODUCTS (PRODUCT_ID)
  )

 ------NOW ADD NEW COLOUMN BY CALCULATING---------------------
 
 ALTER TABLE SALES.ORDER_ITEMS
ADD item_amount AS (quantity*list_price) 

 
 --------- now we will make PRoduction Schemma Tables------
 
 CREATE Table PRODUCTION.CATEGORIES( 
 category_id  INT PRIMARY KEY,
 category_name   VARCHAR(20)      
 )
 ---DROP TABLE PRODUCTION.PRODUCTS
 CREATE TABLE PRODUCTION.PRODUCTS(
 product_id      INT PRIMARY KEY,   
 product_name    VARCHAR(20) NOT NULL,
 last_name       VARCHAR(10),
 brand_id        INT NOT NULL,
 category_id     INT NOT NULL,
 model_year     DATE NOT NULL,
 list_price      INT CHECK(list_price> 0)
 
 )

 ALTER TABLE PRODUCTION.PRODUCTS
 ADD CONSTRAINT fk_brand_id foreign key(brand_id) references PRODUCTION.BRANDS(brand_id)

 CREATE TABLE PRODUCTION.STOCKS(
 store_id      INT ,
 product_id    INT,
 quantity      INT ,
 CONSTRAINT fk_product_Id foreign key (product_id ) REFERENCES PRODUCTION.PRODUCTS(product_id )
  )
  alter table Production.stocks
  add constraint fk_stores_id foreign key(store_id) references sales.stores(store_id)


 CREATE TABLE PRODUCTION.BRANDS(
 
 brand_id     INT PRIMARY KEY,
 brand_name   VARCHAR(20) NOT NULL,
 
 
 )
